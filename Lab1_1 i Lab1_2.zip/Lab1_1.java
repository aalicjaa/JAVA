package com.mycompany.lab1_1; 

import java.util.Scanner; 

public class Lab1_1 

{ 
public static void main(String[] args)  

    {

    Scanner scanner = new Scanner(System.in); 

  

    System.out.print("Podaj imię: "); 

        String imie = scanner.nextLine(); 

  

    System.out.print("Podaj nazwisko: "); 

        String nazwisko = scanner.nextLine(); 

  

    System.out.print("Podaj PESEL: "); 

        String pesel = scanner.nextLine(); 

  

    System.out.print("Podaj miesiąc urodzenia: "); 

        String miesiac_urodzenia = scanner.nextLine(); 

  

    System.out.print("Podaj wiek: "); 

        int wiek = scanner.nextInt(); 

         

    System.out.println("\nPodane informacje:"); 

    System.out.println("Imie: " + imie); 

    System.out.println("Nazwisko: " + nazwisko); 

    System.out.println("PESEL: " + pesel); 

    System.out.println("Miesiąc urodzenia: " + miesiac_urodzenia); 

    System.out.println("Wiek: " + wiek);
    scanner.close(); 
    } 
} 