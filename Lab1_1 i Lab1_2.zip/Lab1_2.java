package com.mycompany.lab1_2; 

import javax.swing.JFrame;  

public class Lab1_2 
{ 
public static void main(String[] args)  
{ 
     JFrame frame = new JFrame(); 

frame.setSize(640, 480); 

frame.setVisible(true); 
} 
} 

 